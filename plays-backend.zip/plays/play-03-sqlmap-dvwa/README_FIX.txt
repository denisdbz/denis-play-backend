Esta pasta está vazia porque o Play 03 passa a receber o target via linha de comando.
Não é necessário arquivo adicional, mas certifique-se de que DVWA está acessível
em http://127.0.0.1:8081 ou ajuste o URL dentro de run.sh.