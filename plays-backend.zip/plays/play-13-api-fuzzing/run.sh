#!/usr/bin/env bash
echo "[INFO] Iniciando Play 13 — API Fuzzing"
# Comando de exemplo
sleep 1
echo "[SUCESSO] API Fuzzing concluído. Relatório gerado."
