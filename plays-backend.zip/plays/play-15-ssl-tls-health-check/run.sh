#!/usr/bin/env bash
echo "[INFO] Iniciando Play 15 — SSL/TLS Health Check"
# Comando de exemplo
sleep 1
echo "[SUCESSO] SSL/TLS Health Check concluído. Relatório gerado."
