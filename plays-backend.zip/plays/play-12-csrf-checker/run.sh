#!/usr/bin/env bash
echo "[INFO] Iniciando Play 12 — CSRF Checker"
# Comando de exemplo
sleep 1
echo "[SUCESSO] CSRF Checker concluído. Relatório gerado."
